import telebot
import yt_dlp
import os
import uuid
import threading
import time
from telebot import types

# Main bot token (factory bot)
MAIN_TOKEN = "7781299877:AAFjm7TidVVsY_PysR5juZU0iB3PhbcpVi4"
bot = telebot.TeleBot(MAIN_TOKEN)

# Create download directory
os.makedirs("downloads", exist_ok=True)

# Download video function
def download_video(url):
    filename = f"downloads/{uuid.uuid4().hex}.mp4"
    ydl_opts = {
        'format': 'best',
        'outtmpl': filename,
        'quiet': True,
        'noplaylist': True,
        'merge_output_format': 'mp4',
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        ydl.download([url])
    return filename

# /start for factory bot
@bot.message_handler(commands=['start'])
def start_cmd(message):
    chat_id = message.chat.id
    with open("FullSaveMeBot_start_en.mp4", "rb") as vid:
        bot.send_video(
            chat_id,
            vid,
            caption=(
                "👋 *Do you want a bot like this?*\n\n"
                "🎬 It's super easy!\n"
                "Just *send me your bot token* and I'll instantly create your own Video Saver Bot.\n\n"
                "⚠️ Make sure your bot is not running somewhere else."
            ),
            parse_mode="Markdown"
        )

# Token handler
@bot.message_handler(func=lambda msg: len(msg.text) > 40 and ":" in msg.text)
def receive_token(message):
    user_token = message.text.strip()
    user_id = message.chat.id

    def factory_start():
        try:
            factory_bot = telebot.TeleBot(user_token)
            bot_info = factory_bot.get_me()
            bot_username = bot_info.username

            # Send instructional video with bot-specific message
            with open("FullSaveMeBot_start_en.mp4", "rb") as vid:
                bot.send_video(
                    user_id,
                    vid,
                    caption=(
                        "🎉 *Your Bot Is Now Active!*\n\n"
                        f"👋 Congrats! Your bot *@{bot_username}* is ready to go.\n\n"
                        "🎥 Watch this guide:\n"
                        "📸 Instagram\n🎵 TikTok\n📘 Facebook\n\n"
                        "✅ Send a link — your bot will download it, watermark-free."
                    ),
                    parse_mode="Markdown"
                )

            # Send and auto-delete sticker
            sticker_msg = bot.send_sticker(user_id, "CAACAgQAAxkBAXvZzWhhOzKXwdJ1N1QX1ZFjiyHX91RDAALFGwACb-TwUaG1C64AARZitjYE")
            threading.Thread(target=lambda: (time.sleep(6), bot.delete_message(user_id, sticker_msg.message_id))).start()

            # START USER BOT
            @factory_bot.message_handler(commands=['start'])
            def sub_start(msg):
                name = msg.from_user.first_name
                welcome = (
                    f"👋 Welcome to your *Ultimate Video Downloader Bot*! 🎬\n\n"
                    f"🚀 Send me any video link from:\n"
                    f"📸 Instagram\n🎵 TikTok\n📘 Facebook\n\n"
                    f"📥 I’ll fetch the video for you in seconds – *simple*, *fast*, and *no watermark*."
                )
                keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
                keyboard.add(types.KeyboardButton("➕ Create Your Bot"))

                markup = types.InlineKeyboardMarkup(row_width=1)
                markup.add(
                    types.InlineKeyboardButton("➕ Add to Chat", url=f"https://t.me/{bot_username}?startgroup=new"),
                    types.InlineKeyboardButton("👥 Invite Friends", url=f"https://t.me/share/url?url=https://t.me/{bot_username}")
                )

                with open("FullSaveMeBot_start_en.mp4", "rb") as vid:
                    factory_bot.send_video(msg.chat.id, vid, caption=welcome, reply_markup=markup, parse_mode="Markdown")

            # Video downloader handler
            @factory_bot.message_handler(func=lambda msg: any(domain in msg.text for domain in ['instagram.com', 'tiktok.com', 'facebook.com', 'fb.watch']))
            def handle_video(msg):
                cid = msg.chat.id
                url = msg.text.strip()

                reaction_msg = factory_bot.send_message(cid, "👀", reply_to_message_id=msg.message_id)
                loading_msg = factory_bot.send_message(cid, "📥 Downloading your video, please wait...")

                try:
                    video = download_video(url)
                    if os.path.getsize(video) > 50 * 1024 * 1024:
                        factory_bot.send_message(cid, "⚠️ Video too large to send via bot (limit is 50MB).")
                        os.remove(video)
                        return

                    with open(video, 'rb') as f:
                        factory_bot.send_video(cid, f, caption="@Videosaver254_bot", reply_to_message_id=msg.message_id)
                    os.remove(video)
                    factory_bot.delete_message(cid, loading_msg.message_id)
                    factory_bot.delete_message(cid, reaction_msg.message_id)

                    # Send sticker after video, delete after 6s
                    vid_sticker = factory_bot.send_sticker(cid, "CAACAgQAAxkBAXvaFmhhPele1Csa_MgkmA78aEA_7MnBAALWDwACa4upUXb4YT1-rEscNgQ")
                    threading.Thread(target=lambda: (time.sleep(6), factory_bot.delete_message(cid, vid_sticker.message_id))).start()

                except Exception as e:
                    factory_bot.send_message(cid, f"❌ Failed to download video:\n{e}", parse_mode="Markdown")

            # Run user bot
            factory_bot.infinity_polling(skip_pending=True)

        except Exception as e:
            bot.send_message(user_id, f"❌ Failed to connect your bot:\n{e}", parse_mode="Markdown")

    threading.Thread(target=factory_start).start()

# Start main factory bot
if __name__ == "__main__":
    print("Factory Bot is running...")
    bot.infinity_polling(skip_pending=True)